
#include "My_TEAM.h"  // For the header file
using namespace std;

TEAM::TEAM() : teamName(""), members("") {}  // Default constructor

TEAM::TEAM(const string& tName, const string& tMembers)  // Parameterized constructor
    : teamName(tName), members(tMembers) {
}

string TEAM::getTeamName() const {  // Getter for team name 
    return teamName;
}

string TEAM::getMembers() const {
    return members;   // Getter for team members
}

