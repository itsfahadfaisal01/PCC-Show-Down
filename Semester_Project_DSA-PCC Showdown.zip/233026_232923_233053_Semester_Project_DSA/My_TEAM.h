

#include <string>  // For string class
using namespace std;

class TEAM {  // TEAM class
private:
    string teamName;
    string members;

public:
    TEAM();
    TEAM(const string& tName, const string& tMembers);  // Constructor
	string getTeamName() const;  // Getter for team name
	string getMembers() const; // Getter for team members
};

