#include "Team.h"  // For the header file
using namespace std;  

void Team::setTeamName(const string& name) {  // For setting the team name
    teamName = name;
}

void Team::setMembers(const string& mem) {  // For setting the team members
    members = mem;
}

string Team::getTeamName() const {   // For getting the team name
    return teamName;
}

string Team::getMembers() const {    // For getting the team members
    return members;
}