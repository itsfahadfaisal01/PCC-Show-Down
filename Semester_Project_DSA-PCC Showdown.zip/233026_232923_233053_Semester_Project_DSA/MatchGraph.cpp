
#include "MatchGraph.h"
 
MatchGraph::MatchGraph() {  
    for (int i = 0; i < 8; ++i)  // Initialize the adjacency matrix
        for (int j = 0; j < 8; ++j)
            adjMatrix[i][j] = false;
}

void MatchGraph::addEdge(int team1, int team2) {  // Add an edge between two teams in the adjacency matrix 
    adjMatrix[team1][team2] = true;
    adjMatrix[team2][team1] = true;
}

bool MatchGraph::hasEdge(int team1, int team2) const {  // Check if there is an edge between two teams in the adjacency matrix
    return adjMatrix[team1][team2];
}
