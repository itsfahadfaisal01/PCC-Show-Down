#include <string>
using namespace std;

// Maximum number of teams constexpr auto is used for compile-time constants this helps in performance and suggested by  the compiler to optimize
constexpr auto MAX_TEAMS = 16;

class Team {   // Team class
private:
    string teamName;
    string members;

public:
    void setTeamName(const string& name);  // Member functions
    void setMembers(const string& mem);  // Member functions

    string getTeamName() const;  // Member functions
	string getMembers() const;   // Member functions
};

