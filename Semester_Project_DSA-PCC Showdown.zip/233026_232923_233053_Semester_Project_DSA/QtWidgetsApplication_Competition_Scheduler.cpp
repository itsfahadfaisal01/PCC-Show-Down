#include "QtWidgetsApplication_Competition_Scheduler.h" // For the header file
#include <QGridLayout>  // For grid layouts
#include <QLineEdit>  // For line edits
#include <QLabel> // For labels
#include <QPushButton> // For buttons
#include <QMessageBox> // For message boxes
#include <regex>    // For regular expressions
#include <iostream> // For basic input/output
#include <fstream> // For file input/output
#include <string>  // For strings
#include <ctime>  // For time
#include <cstdlib> // For random number generation
#include <algorithm> // For algorithms
#include <cctype> // For case conversion
#include <QTableWidgetItem>  // For populating the table widget
#include <queue> // For priority queue
#include <iomanip> // For manipulating the output stream
#include <sstream> // For string streams
#include "Team.h" // For Team class
#include "My_TEAM.h" // For TEAM class
#include "MatchGraph.h" // For MatchGraph class

using namespace std;


// here is the constructor for the class QtWidgetsApplication_Competition_Scheduler
QtWidgetsApplication_Competition_Scheduler::QtWidgetsApplication_Competition_Scheduler(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);

     


    // Here I am using the signal method in the QtWidgetsApplication_Competition_Scheduler.h file to connect buttons to slots
    connect(ui.btnHome, &QPushButton::clicked, this, &QtWidgetsApplication_Competition_Scheduler::showHomePage);
    connect(ui.btnRegistration, &QPushButton::clicked, this, &QtWidgetsApplication_Competition_Scheduler::showRegistrationPage);
    connect(ui.btnSchedule, &QPushButton::clicked, this, &QtWidgetsApplication_Competition_Scheduler::showRankingPage);
    connect(ui.btnRanking, &QPushButton::clicked, this, &QtWidgetsApplication_Competition_Scheduler::showSchedulePage);


    // Connecting the buttons to their respective slots for the Registration page
    connect(ui.btnSave, &QPushButton::clicked, this, &QtWidgetsApplication_Competition_Scheduler::saveTeamData);
    connect(ui.btnClear, &QPushButton::clicked, this, &QtWidgetsApplication_Competition_Scheduler::clearTeamData);

    // Connecting the buttons to their respective slots for the Ranking page
     connect(ui.btnRank, &QPushButton::clicked, this, &QtWidgetsApplication_Competition_Scheduler::calculateAndDisplayRanks);

	// Connecting the buttons to their respective slots Create group for the Schedule page
     connect(ui.btnCreategroup, &QPushButton::clicked, this, &QtWidgetsApplication_Competition_Scheduler::createGroupsAndDisplay);

     // Connecting the buttons to their respective slots First round for the Schedule page
     connect(ui.btnFirstround, &QPushButton::clicked, this, &QtWidgetsApplication_Competition_Scheduler::scheduleFirstRound);

     // Connecting the buttons to their respective slots Second round for the Schedule page
	  connect(ui.btnSecondround, &QPushButton::clicked, this, &QtWidgetsApplication_Competition_Scheduler::scheduleSecondRound);
  
      // Connecting the buttons to their respective slots Semifinal for the Schedule page
      connect(ui.btnSemifinal, &QPushButton::clicked, this, &QtWidgetsApplication_Competition_Scheduler::scheduleSemifinalRound);
     
      // Connecting the buttons to their respective slots Final for the Schedule page
      connect(ui.btnFinal, &QPushButton::clicked, this, &QtWidgetsApplication_Competition_Scheduler::scheduleFinalRound);
}

// here is the slot implementations

void QtWidgetsApplication_Competition_Scheduler::showHomePage()
{
    ui.stackedWidget->setCurrentIndex(0); // this will go to page 0
}

void QtWidgetsApplication_Competition_Scheduler::showRegistrationPage()
{
    ui.stackedWidget->setCurrentIndex(1); // this will go to page 1
}

void QtWidgetsApplication_Competition_Scheduler::showRankingPage()
{
    ui.stackedWidget->setCurrentIndex(2); // this will go to page 2
}

void QtWidgetsApplication_Competition_Scheduler::showSchedulePage() 
{
    ui.stackedWidget->setCurrentIndex(3); // this will go  to page 3
}
void QtWidgetsApplication_Competition_Scheduler::saveTeamData()
{
    QString teamName = ui.teamName->text();
    QString member1 = ui.member1->text();
    QString member2 = ui.member2->text();
    QString member3 = ui.member3->text();

     // these will Clear input fields after saving
    ui.teamName->clear(); 
    ui.member1->clear();
    ui.member2->clear();
    ui.member3->clear();

    static int teamNumber = 1;

    // Validate inputs
    regex nameRegex("^[A-Za-z ]+$");  
    if (teamName.isEmpty() || member1.isEmpty() || !regex_match(member1.toStdString(), nameRegex))
    {
        QMessageBox::warning(this, "Input Error", "Please provide valid inputs. Team name can be any characters, but member names must be alphabetic.");
        return;
    }

    // Save data to file
    ofstream outFile("teams.txt", ios::app);
    if (!outFile)
    {
        QMessageBox::critical(this, "File Error", "Unable to open the file for saving team data.");
        return;
    }

    outFile << "Team " << teamNumber++ << ":\n";
    outFile << "  Team Name: " << teamName.toStdString() << "\n";
    outFile << "  Members: " << member1.toStdString();
    if (!member2.isEmpty()) outFile << ", " << member2.toStdString();
    if (!member3.isEmpty()) outFile << ", " << member3.toStdString();
    outFile << "\n\n";

    outFile.close();
    QMessageBox::information(this, "Success", "Team data saved successfully!");
}

void QtWidgetsApplication_Competition_Scheduler::clearTeamData()
{
    

    ofstream outFile("teams.txt", ios::trunc); // Clear file contents by the file opened in trunc mode
    if (outFile)
    {
        outFile.close();
        QMessageBox::information(this, "Success", "All data has been cleared!");
    }
    else
    {
        QMessageBox::critical(this, "File Error", "Unable to clear file contents.");
    }
}




void QtWidgetsApplication_Competition_Scheduler::calculateAndDisplayRanks() {
    // Open the file for reading
    ifstream inFile("teams.txt");
    if (!inFile) {

        QMessageBox::critical(this, "File Error", "Unable to open the teams file for reading.");
        return;

    }

    Team teams[MAX_TEAMS]; // Array of Team objects
    int teamCount = 0;
    string line;

    // Regex patterns for parsing
    regex teamNameRegex(R"(Team Name:\s*(.+))"); // Matches "Team Name: <content>"
    regex membersRegex(R"(Members:\s*(.+))");   // Matches "Members: <content>"

    while (getline(inFile, line) && teamCount < MAX_TEAMS) {
        smatch match;

        // Check for Team Name
        if (regex_search(line, match, teamNameRegex)) {
            teams[teamCount].setTeamName(match[1]);
        }
        // Check for Members
        else if (regex_search(line, match, membersRegex)) {
            teams[teamCount].setMembers(match[1]);
            teamCount++; // Move to the next team after capturing members
        }
    }
    inFile.close();

    // Ensure there are exactly 16 teams
    if (teamCount < MAX_TEAMS) {
        QMessageBox::warning(this, "Insufficient Data", "Please ensure there are exactly 16 teams in the file.");
        return;
    }

    // Generate random ranks
    int ranks[MAX_TEAMS]{};
    for (int i = 0; i < MAX_TEAMS; i++) ranks[i] = i + 1;

    srand(static_cast<unsigned>(time(nullptr))); // Seed randomness
    for (int i = 0; i < MAX_TEAMS; i++) { // Shuffle ranks
        int j = rand() % MAX_TEAMS;
        swap(ranks[i], ranks[j]);
    }

    // Open the file for writing the schedule
    ofstream outFile("schedule.txt");
    if (!outFile) {
        QMessageBox::critical(this, "File Error", "Unable to open the schedule file for writing.");
        return;
    }

    // Clear the tableWidget
    ui.tableWidget->setRowCount(0);

    // Display the ranked teams
    for (int i = 0; i < MAX_TEAMS; i++) {
        outFile << "Rank " << ranks[i] << ":\n";
        outFile << "  Team Name: " << teams[i].getTeamName() << "\n";
        outFile << "  Members: " << teams[i].getMembers() << "\n\n";

        // Add data to the tableWidget
        int row = ui.tableWidget->rowCount();
        ui.tableWidget->insertRow(row);

        QTableWidgetItem* rankItem = new QTableWidgetItem(QString::number(ranks[i]));
        QTableWidgetItem* teamItem = new QTableWidgetItem(QString::fromStdString(teams[i].getTeamName()));
        QTableWidgetItem* membersItem = new QTableWidgetItem(QString::fromStdString(teams[i].getMembers()));

        ui.tableWidget->setItem(row, 0, rankItem);
        ui.tableWidget->setItem(row, 1, teamItem);
        ui.tableWidget->setItem(row, 2, membersItem);
    }
    outFile.close();

    QMessageBox::information(this, "Success", "Ranks calculated and displayed successfully!");
}





void QtWidgetsApplication_Competition_Scheduler::createGroupsAndDisplay() {
    // Open the file to read scheduled data
    ifstream inFile("schedule.txt");
    if (!inFile) {
        QMessageBox::critical(this, "File Error", "Unable to open the schedule file for reading.");
        return;
    }

    Team teams[MAX_TEAMS];
    int ranks[MAX_TEAMS]{};
    int teamCount = 0;
    string line;

    // Regex patterns for parsing
    regex rankRegex(R"(Rank\s+(\d+):)");
    regex teamNameRegex(R"(Team Name:\s*(.+))");
    regex membersRegex(R"(Members:\s*(.+))");

    while (getline(inFile, line) && teamCount < MAX_TEAMS) {
        smatch match;

        // Extract rank
        if (regex_search(line, match, rankRegex)) {

            ranks[teamCount] = stoi(match[1]);

        }
        // Extract team name
        else if (regex_search(line, match, teamNameRegex)) {

            teams[teamCount].setTeamName(match[1]);

        }
        // Extract members
        else if (regex_search(line, match, membersRegex)) {

            teams[teamCount].setMembers(match[1]);
            teamCount++;

        }
    }
    inFile.close();

    // Sort teams based on ranks (ascending order)
    for (int i = 0; i < teamCount - 1; ++i) {
        for (int j = 0; j < teamCount - i - 1; ++j) {
            if (ranks[j] > ranks[j + 1]) {
                swap(ranks[j], ranks[j + 1]);
                swap(teams[j], teams[j + 1]);
            }
        }
    }

    // Divide teams into two groups
    Team groupA[8], groupB[8];
    for (int i = 0; i < 8; ++i) {
        groupA[i] = teams[i];
        groupB[i] = teams[i + 8];
    }

   
   // Get current date and time
    time_t now = time(nullptr);
    char dateTimeBuffer[100];
    tm localTime;

    if (localtime_s(&localTime, &now) == 0) {
        strftime(dateTimeBuffer, sizeof(dateTimeBuffer), "%Y-%m-%d %H:%M:%S", &localTime);
    }
    else {
        QMessageBox::critical(this, "Time Error", "Unable to retrieve the current local time.");
        return;
    }


    // Save groups' results to a file
    ofstream outFile("results.txt");
    if (!outFile) {
        QMessageBox::critical(this, "File Error", "Unable to open results.txt for writing.");
        return;
    }

    outFile << "Group A:\n";
    for (int i = 0; i < 8; ++i) {
        outFile << "Team Name: " << groupA[i].getTeamName()
            << ", Members: " << groupA[i].getMembers()
            << ", Rank: " << ranks[i]
            << ", Date/Time: " << dateTimeBuffer << "\n";
    }

    outFile << "\nGroup B:\n";
    for (int i = 0; i < 8; ++i) {
        outFile << "Team Name: " << groupB[i].getTeamName()
            << ", Members: " << groupB[i].getMembers()
            << ", Rank: " << ranks[i + 8]
            << ", Date/Time: " << dateTimeBuffer << "\n";
    }

    outFile.close();

    // Display Group A in tableWidgetA
    ui.tableWidgetA->setRowCount(0);
    for (int i = 0; i < 8; ++i) {
        int row = ui.tableWidgetA->rowCount();
        ui.tableWidgetA->insertRow(row);

        QTableWidgetItem* rankItem = new QTableWidgetItem(QString::number(ranks[i]));
        QTableWidgetItem* teamItem = new QTableWidgetItem(QString::fromStdString(groupA[i].getTeamName()));
        QTableWidgetItem* membersItem = new QTableWidgetItem(QString::fromStdString(groupA[i].getMembers()));
        QTableWidgetItem* dateTimeItem = new QTableWidgetItem(QString::fromStdString(dateTimeBuffer));

        ui.tableWidgetA->setItem(row, 0, rankItem);
        ui.tableWidgetA->setItem(row, 1, teamItem);
        ui.tableWidgetA->setItem(row, 2, membersItem);
        ui.tableWidgetA->setItem(row, 3, dateTimeItem);
    }

    // Display Group B in tableWidgetB
    ui.tableWidgetB->setRowCount(0);
    for (int i = 0; i < 8; ++i) {
        int row = ui.tableWidgetB->rowCount();
        ui.tableWidgetB->insertRow(row);

        QTableWidgetItem* rankItem = new QTableWidgetItem(QString::number(ranks[i + 8]));
        QTableWidgetItem* teamItem = new QTableWidgetItem(QString::fromStdString(groupB[i].getTeamName()));
        QTableWidgetItem* membersItem = new QTableWidgetItem(QString::fromStdString(groupB[i].getMembers()));
        QTableWidgetItem* dateTimeItem = new QTableWidgetItem(QString::fromStdString(dateTimeBuffer));

        ui.tableWidgetB->setItem(row, 0, rankItem);
        ui.tableWidgetB->setItem(row, 1, teamItem);
        ui.tableWidgetB->setItem(row, 2, membersItem);
        ui.tableWidgetB->setItem(row, 3, dateTimeItem);
    }

    QMessageBox::information(this, "Success", "Groups created and displayed successfully!");
}


// Class for the linked list node
class TeamNode {
private:
    string teamName;
    string members; // Placeholder for team members
    TeamNode* nextNode;

public:
    TeamNode(const string& name, const string& teamMembers)
        : teamName(name), members(teamMembers), nextNode(nullptr) {
    }

    const string& getName() const { return teamName; }
    const string& getMembers() const { return members; }
    void setNext(TeamNode* next) { nextNode = next; }
    TeamNode* getNext() const { return nextNode; }

};

// Class for the linked list
class TeamList {

private:

    TeamNode* head;
    TeamNode* tail;
    int size;

public:
    TeamList() : head(nullptr), tail(nullptr), size(0) {}

    ~TeamList() {

        while (head) {

            TeamNode* temp = head;
            head = head->getNext();
            delete temp;

        }
    }

    void addTeam(const string& team, const string& members) {
        TeamNode* newNode = new TeamNode(team, members);
        if (tail) {
            tail->setNext(newNode);
        }
        else {
            head = newNode;
        }
        tail = newNode;
        size++;
    }

    string removeFirst(string& members) {
        if (!head) return "";
        TeamNode* temp = head;
        string team = temp->getName();
        members = temp->getMembers();
        head = head->getNext();
        if (!head) tail = nullptr;
        delete temp;
        size--;
        return team;
    }

    bool isEmpty() const { return head == nullptr; }
    int getSize() const { return size; }
};
void QtWidgetsApplication_Competition_Scheduler::scheduleFirstRound() {
    ifstream inFile("results.txt");
    if (!inFile) {
        QMessageBox::critical(this, "File Error", "Unable to open results.txt for reading.");
        return;
    }

    // Read teams into TeamLists
    TeamList groupAlpha;
    TeamList groupBeta;
    string line;
    bool isGroupAlpha = true;

    while (getline(inFile, line)) {
        if (line == "Group B:") {
            isGroupAlpha = false;
            continue;
        }
        if (line == "Group A:") continue; // Skip the "Group A:" line

        if (!line.empty()) {
            // Extract team name and members
            size_t pos = line.find("Members:");
            if (pos != string::npos) {
                // Extract team name (everything before "Members:")
                string teamName = line.substr(0, pos);
                teamName = teamName.substr(11); // Remove "Team Name: " part

                // Extract members (everything after "Members:")
                string members = line.substr(pos + 8); // Skip "Members:" part
                members = members.erase(0, members.find_first_not_of(" ")); // Remove leading spaces

                // Stop at the next keyword if present (e.g., "Rank:", "Date/Time:")
                size_t rankPos = members.find("Rank:");
                size_t dateTimePos = members.find("Date/Time:");
                if (rankPos != string::npos) {

                    members = members.substr(0, rankPos);

                }
                if (dateTimePos !=string::npos) {

                    members = members.substr(0, dateTimePos);

                }

                // Trim any trailing spaces or newlines
                members = members.erase(members.find_last_not_of(" \n\r\t") + 1);

                if (isGroupAlpha) {

                    groupAlpha.addTeam(teamName, members);

                }
                else {

                    groupBeta.addTeam(teamName, members);

                }
            }
        }
    }


    inFile.close();

    if (groupAlpha.getSize() != 8 || groupBeta.getSize() != 8) {
        QMessageBox::warning(this, "Invalid Data", "Ensure that both Group A and Group B contain exactly 8 valid teams.");
        return;
    }

    ofstream outFile("Firstround.txt");
    if (!outFile) {
        QMessageBox::critical(this, "File Error", "Unable to open Firstround.txt for writing.");
        return;
    }

    // Seed randomness
    srand(static_cast<unsigned>(time(nullptr)));

    // Configure the table widget
    ui.tableWidgetFR->setRowCount(8);
    ui.tableWidgetFR->setColumnCount(5); // Columns: Match, Team Name, Members, Date/Time, Status
    QStringList headers = { "Match", "Team Name", "Members", "Date/Time", "Status" };
    ui.tableWidgetFR->setHorizontalHeaderLabels(headers);

    for (int i = 0; i < 8; ++i) {
        if (groupAlpha.isEmpty() || groupBeta.isEmpty()) break;

        string membersAlpha, membersBeta;
        string teamAlpha = groupAlpha.removeFirst(membersAlpha);
        string teamBeta = groupBeta.removeFirst(membersBeta);

        // Select a random winner
        string winnerTeam = (rand() % 2 == 0) ? teamAlpha : teamBeta;
        string winnerMembers = (winnerTeam == teamAlpha) ? membersAlpha : membersBeta;

        // Get current date and time
        time_t now = time(nullptr);
        char dateTimeBuffer[100];
        tm localTime;

        localtime_s(&localTime, &now);
        strftime(dateTimeBuffer, sizeof(dateTimeBuffer), "%Y-%m-%d %H:%M:%S", &localTime);
        string dateTime = dateTimeBuffer;

        // Write to file
        outFile << "Match: Firstround\n"
            << "Team Name: " << winnerTeam << "\n"
            << "Members: " << winnerMembers << "\n"
            << "Date/Time: " << dateTime << "\n"
            << "Status: FirstRound Completed\n\n";

        // Populate table
        ui.tableWidgetFR->setItem(i, 0, new QTableWidgetItem(QString::fromStdString("Match " + std::to_string(i + 1))));
        ui.tableWidgetFR->setItem(i, 1, new QTableWidgetItem(QString::fromStdString(winnerTeam)));
        ui.tableWidgetFR->setItem(i, 2, new QTableWidgetItem(QString::fromStdString(winnerMembers)));
        ui.tableWidgetFR->setItem(i, 3, new QTableWidgetItem(QString::fromStdString(dateTime)));
        ui.tableWidgetFR->setItem(i, 4, new QTableWidgetItem("FirstRound Completed"));
    }

    outFile.close();
    QMessageBox::information(this, "First Round Scheduled", "The first round has been successfully scheduled.");
}


    
// Queue Class for Team Management
class Queue {
private:
    class Node {
    public:
        TEAM team;
        Node* next;

        Node(const TEAM& t) : team(t), next(nullptr) {}
    };

    Node* front;
    Node* rear;

public:
    Queue() : front(nullptr), rear(nullptr) {}

    ~Queue() {
        while (!isEmpty()) dequeue();
    }

    void enqueue(const TEAM& team) {
        Node* newNode = new Node(team);
        if (!rear) {
            front = rear = newNode;
        }
        else {
            rear->next = newNode;
            rear = newNode;
        }
    }

    TEAM dequeue() {
        if (isEmpty()) throw std::runtime_error("Queue is empty");

        Node* temp = front;
        TEAM team = front->team;
        front = front->next;

        if (!front) rear = nullptr;

        delete temp;
        return team;
    }

    bool isEmpty() const { return front == nullptr; }
};



// Function to schedule second round
void QtWidgetsApplication_Competition_Scheduler::scheduleSecondRound() {
    ifstream inFile("Firstround.txt");
    if (!inFile) {
        QMessageBox::critical(this, "File Error", "Unable to open FirstRound.txt for reading.");
        return;
    }

    // Step 1: Read teams into a Queue using robust regex
    Queue teamQueue;
    string line;
    regex teamRegex(R"(Team Name:\s*([\w\s#@]+))");
    regex membersRegex(R"(Members:\s*([\w\s,]+))");

    string teamName, members;
    while (getline(inFile, line)) {
        if (regex_search(line, teamRegex)) {
            teamName = regex_replace(line, teamRegex, "$1");
        }
        else if (regex_search(line, membersRegex)) {
            members = regex_replace(line, membersRegex, "$1");
            teamQueue.enqueue(TEAM(teamName, members));
        }
    }
    inFile.close();

    // Step 2: Ensure 8 teams
    TEAM teams[8];
    int teamCount = 0;
    while (!teamQueue.isEmpty() && teamCount < 8) {
        teams[teamCount++] = teamQueue.dequeue();
    }
    if (teamCount != 8) {
        QMessageBox::critical(this, "Error", "Exactly 8 teams are required for the second round.");
        return;
    }

    // Step 3: Setup match tracking
    MatchGraph matchGraph;
    ofstream outFile("Secondround.txt");
    if (!outFile) {
        QMessageBox::critical(this, "File Error", "Unable to open SecondRound.txt for writing.");
        return;
    }

    ui.tableWidgetSR->setRowCount(4);
    ui.tableWidgetSR->setColumnCount(5);
    QStringList headers = { "Match", "Team Name", "Members", "Date/Time", "Status" };
    ui.tableWidgetSR->setHorizontalHeaderLabels(headers);

    bool used[8] = { false };
    srand(static_cast<unsigned>(time(nullptr)));

    for (int match = 0; match < 4; ++match) {
        int t1, t2;

        // Ensure fair and unique matchups
        do {
            t1 = rand() % 8;
            t2 = rand() % 8;
        } while (t1 == t2 || used[t1] || used[t2] || matchGraph.hasEdge(t1, t2));

        used[t1] = used[t2] = true;
        matchGraph.addEdge(t1, t2);

        // Pick a random winner
        TEAM winner = (rand() % 2 == 0) ? teams[t1] : teams[t2];

        // Get current date and time
        time_t now = time(nullptr);
        char dateTimeBuffer[100];
        tm localTime;

        localtime_s(&localTime, &now);
        strftime(dateTimeBuffer, sizeof(dateTimeBuffer), "%Y-%m-%d %H:%M:%S", &localTime);
        string dateTime = dateTimeBuffer;

        // Write match details
        outFile << "Match: SecondRound\n"
            << "Team Name: " << winner.getTeamName() << "\n"
            << "Members: " << winner.getMembers() << "\n"
            << "Date/Time: " << dateTime << "\n"
            << "Status: SecondRound Completed\n\n";

        // Display match details in the table
        ui.tableWidgetSR->setItem(match, 0, new QTableWidgetItem(QString::fromStdString("Match " + std::to_string(match + 1))));
        ui.tableWidgetSR->setItem(match, 1, new QTableWidgetItem(QString::fromStdString(winner.getTeamName())));
        ui.tableWidgetSR->setItem(match, 2, new QTableWidgetItem(QString::fromStdString(winner.getMembers())));
        ui.tableWidgetSR->setItem(match, 3, new QTableWidgetItem(QString::fromStdString(dateTime)));
        ui.tableWidgetSR->setItem(match, 4, new QTableWidgetItem("SecondRound Completed"));
    }

    outFile.close();
    QMessageBox::information(this, "Success", "The Second Round has been successfully scheduled.");
}


// Function to schedule the Semi-Final Round
void QtWidgetsApplication_Competition_Scheduler::scheduleSemifinalRound() {
    std::ifstream inFile("Secondround.txt");
    if (!inFile) {
        QMessageBox::critical(this, "File Error", "Unable to open SecondRound.txt for reading.");
        return;
    }

    // Step 1: Extract 4 unique teams using regex
    regex teamRegex(R"(Team Name:\s*([\w\s#@]+))");
    regex membersRegex(R"(Members:\s*([\w\s,]+))");

    map<int, TEAM> teamMap; // Use map to store teams
    string line, teamName, members;
    int index = 0;

    while (getline(inFile, line)) {
        if (regex_search(line, teamRegex)) {
            teamName = regex_replace(line, teamRegex, "$1");
        }
        else if (regex_search(line, membersRegex)) {
            members = regex_replace(line, membersRegex, "$1");
            teamMap[index++] = TEAM(teamName, members);
        }
    }
    inFile.close();

    if (teamMap.size() != 4) {
        QMessageBox::critical(this, "Error", "Exactly 4 unique teams are required for the Semi-Final.");
        return;
    }

    ofstream outFile("Semifinal.txt");
    if (!outFile) {
        QMessageBox::critical(this, "File Error", "Unable to open SemiFinal.txt for writing.");
        return;
    }

    // TableWidget Setup
    ui.tableWidgetSF->setRowCount(2);
    ui.tableWidgetSF->setColumnCount(5);
    QStringList headers = { "Match", "Team Name", "Members", "Date/Time", "Status" };
    ui.tableWidgetSF->setHorizontalHeaderLabels(headers);

    MatchGraph matchGraph;
    bool used[4] = { false };
    srand(static_cast<unsigned>(time(nullptr)));

    for (int match = 0; match < 2; ++match) {
        int t1, t2;

        do {
            t1 = rand() % 4;
            t2 = rand() % 4;
        } while (t1 == t2 || used[t1] || used[t2] || matchGraph.hasEdge(t1, t2));

        used[t1] = used[t2] = true;
        matchGraph.addEdge(t1, t2);

        TEAM winner = (rand() % 2 == 0) ? teamMap[t1] : teamMap[t2];

        // Generate Date-Time
        time_t now = time(nullptr);
        char dateTimeBuffer[100];
        tm localTime;
        localtime_s(&localTime, &now);
        strftime(dateTimeBuffer, sizeof(dateTimeBuffer), "%Y-%m-%d %H:%M:%S", &localTime);
        string dateTime = dateTimeBuffer;

        // Write to File
        outFile << "Match: SemiFinal\n"
            << "Team Name: " << winner.getTeamName() << "\n"
            << "Members: " << winner.getMembers() << "\n"
            << "Date/Time: " << dateTime << "\n"
            << "Status: SemiFinal Completed\n\n";

        // Populate TableWidget
        ui.tableWidgetSF->setItem(match, 0, new QTableWidgetItem(QString::fromStdString("Match " + std::to_string(match + 1))));
        ui.tableWidgetSF->setItem(match, 1, new QTableWidgetItem(QString::fromStdString(winner.getTeamName())));
        ui.tableWidgetSF->setItem(match, 2, new QTableWidgetItem(QString::fromStdString(winner.getMembers())));
        ui.tableWidgetSF->setItem(match, 3, new QTableWidgetItem(QString::fromStdString(dateTime)));
        ui.tableWidgetSF->setItem(match, 4, new QTableWidgetItem("SemiFinal Completed"));
    }

    outFile.close();
    QMessageBox::information(this, "Success", "The Semi-Final has been successfully scheduled.");
}


// Function to schedule the Final Round
void QtWidgetsApplication_Competition_Scheduler::scheduleFinalRound() {
    ifstream inFile("Semifinal.txt");
    if (!inFile) {
        QMessageBox::critical(this, "File Error", "Unable to open SemiFinal.txt for reading.");
        return;
    }

    // Step 1: Use map to store teams
    map<int, TEAM> teamMap;
    regex teamRegex(R"(Team Name:\s*([\w\s#@\-!]+),?\s*)"); // Updated regex for Team Name
    regex membersRegex(R"(Members:\s*([\w\s,]+))");         // Updated regex for Members

    string line, teamName, members;
    int index = 0;

    while (getline(inFile, line)) {
        smatch matchResult;

        if (regex_search(line, matchResult, teamRegex)) {
            teamName = matchResult[1]; // Extract team name
        }

        if (regex_search(line, matchResult, membersRegex)) {
            members = matchResult[1]; // Extract members
            teamMap[index++] = TEAM(teamName, members);
        }
    }
    inFile.close();

    // Step 2: Verify we have exactly 2 teams
    if (teamMap.size() != 2) {
        QMessageBox::critical(this, "Error", "Exactly 2 teams are required for the Final.");
        return;
    }

    // Step 3: Select winner and runner-up randomly
    srand(static_cast<unsigned>(time(nullptr)));
    int winnerIndex = rand() % 2;
    int runnerUpIndex = (winnerIndex == 0) ? 1 : 0;

    TEAM winnerTeam = teamMap[winnerIndex];
    TEAM runnerUpTeam = teamMap[runnerUpIndex];

    // Generate Date-Time
    time_t now = time(nullptr);
    char dateTimeBuffer[100];
    tm localTime;
    localtime_s(&localTime, &now);
    strftime(dateTimeBuffer, sizeof(dateTimeBuffer), "%Y-%m-%d %H:%M:%S", &localTime);
    string dateTime = dateTimeBuffer;

    // Write Results to Final.txt
    ofstream outFile("Final.txt");
    if (!outFile) {
        QMessageBox::critical(this, "File Error", "Unable to open Final.txt for writing.");
        return;
    }

    outFile << "Winner Team Name: " << winnerTeam.getTeamName() << "\n"
        << "Runner-Up Team Name: " << runnerUpTeam.getTeamName() << "\n"
        << "Date/Time: " << dateTime << "\n"
        << "Status: Final Round Completed\n";
    outFile.close();

    // Populate TableWidget
    ui.tableWidgetF->setRowCount(2);
    ui.tableWidgetF->setColumnCount(5);
    QStringList headers = { "Position", "Team Name", "Members", "Date/Time", "Status" };
    ui.tableWidgetF->setHorizontalHeaderLabels(headers);

    // Winner
    ui.tableWidgetF->setItem(0, 0, new QTableWidgetItem("Winner"));
    ui.tableWidgetF->setItem(0, 1, new QTableWidgetItem(QString::fromStdString(winnerTeam.getTeamName())));
    ui.tableWidgetF->setItem(0, 2, new QTableWidgetItem(QString::fromStdString(winnerTeam.getMembers())));
    ui.tableWidgetF->setItem(0, 3, new QTableWidgetItem(QString::fromStdString(dateTime)));
    ui.tableWidgetF->setItem(0, 4, new QTableWidgetItem("Winner Declared"));

    // Runner-Up
    ui.tableWidgetF->setItem(1, 0, new QTableWidgetItem("Runner-Up"));
    ui.tableWidgetF->setItem(1, 1, new QTableWidgetItem(QString::fromStdString(runnerUpTeam.getTeamName())));
    ui.tableWidgetF->setItem(1, 2, new QTableWidgetItem(QString::fromStdString(runnerUpTeam.getMembers())));
    ui.tableWidgetF->setItem(1, 3, new QTableWidgetItem(QString::fromStdString(dateTime)));
    ui.tableWidgetF->setItem(1, 4, new QTableWidgetItem("Runner-Up Declared"));

    // Display Notification
    QString message = "Congratulations to Winner: " + QString::fromStdString(winnerTeam.getTeamName()) + "!";
    QMessageBox::information(this, "Hackathon Event Complete", message);
}




QtWidgetsApplication_Competition_Scheduler::~QtWidgetsApplication_Competition_Scheduler()
{}
