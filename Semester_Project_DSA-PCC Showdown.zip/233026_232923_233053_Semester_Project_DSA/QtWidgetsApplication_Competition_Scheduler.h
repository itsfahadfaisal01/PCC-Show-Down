#include <QtWidgets/QMainWindow>  // This is the QMainWindow class which is used to create the main window of the application
#include "ui_QtWidgetsApplication_Competition_Scheduler.h"  // This is the generated header file for the UI of the application

class QtWidgetsApplication_Competition_Scheduler : public QMainWindow
{
    Q_OBJECT  // This is a macro used to indicate that the class is a Qt class and should be processed by the Qt meta-object system

public:
	QtWidgetsApplication_Competition_Scheduler(QWidget* parent = nullptr);  // Constructor for the main window
	~QtWidgetsApplication_Competition_Scheduler();  // Destructor for the main window

    private slots:
		// Slots for the buttons on the main window of the application 
        void showHomePage();
        void showRegistrationPage();
        void showRankingPage();
        void showSchedulePage();

        void saveTeamData(); // Remove parameters
        void clearTeamData(); // Remove parameters
         
         void calculateAndDisplayRanks(); //  This is the Slot for the Rank button

         void createGroupsAndDisplay(); //  This is the Slot for the  Create Group button

         void scheduleFirstRound();  // This is the Slot for the First Round button
         void scheduleSecondRound();  // This is the Slot for the Second Round button
         void scheduleSemifinalRound();  // This is the Slot for the Final Round button
         void scheduleFinalRound();  // This is the Slot for the Final Round button

private:

    Ui::QtWidgetsApplication_Competition_SchedulerClass ui;  // This is the generated class for the UI of the application

};
