#include "QtWidgetsApplication_Competition_Scheduler.h"
#include <QtWidgets/QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QtWidgetsApplication_Competition_Scheduler w;
    w.show();
    return a.exec();
}
