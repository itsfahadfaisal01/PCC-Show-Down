
class MatchGraph {  // Class to represent the match graph
private:
	bool adjMatrix[8][8];   // Adjacency matrix to store the edges between the teams

public:
    MatchGraph();
    void addEdge(int team1, int team2);   // Function to add an edge between two teams
    bool hasEdge(int team1, int team2) const;  // Function to check if there is an edge between two teams
};

